// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // provides standard exception types
#include <exception> // provides base exception class
#include <string>    // provides std::string for storing custom exception method

// custom exception class derived from std::exception.
// this allows us to create a custom exception  that can be handled 
// separately from other standard exceptions.
class ApplicationException : public std::exception {
private:
    std::string message; // stores the message associated with the custom exception

public:
    // the constructor allows a custom error message to be passed
    // when an ApplicationException is created.
    explicit ApplicationException(const std::string& errorMessage) : message(errorMessage) {
    }

    // override what() so that the exception can provide its message when
    // it is caught by an exception handler
    const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic()
{
    // a standard runtime_error is through here to show how a standard
    //  excpetion can be generated
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Standard exception thrown inside \'do_even_more_custom_application_logic()\'");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // the call that can throw an exception is placed inside a try block
    // so that the error can be handled instead of terminating the program
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // catch the standard excpetion derived from std::exception.
        // the what() method displays the specifc error message.
        // after the exception is caught, processing continues
        std::cout << "Standard exception caught in \'do_custom_application_logic()\' : "  << ex.what() << std::endl;
    }

    // a custom ApplicationException is thrown here.
    // it will be handles explicitly by the first catch block in main()
    throw ApplicationException("Application exception thrown inside \'do_custom_application_logic()\'");
    
    // this statement should not be reached because the exception above
    // tranfers the control to the catch block in main()
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // check for a zero denominator before attempting division.
    // std::invalid_argument is used because a denominator of zero is
    // invalid for this function
    if (den == 0.0f) {
        throw std::invalid_argument("Divide-by-zero error in \'divide()\'");
    }
    // IF the denominator is NOT zero, perform division
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // place the call to divide() inside a try block because
    // divide() can throw a std::invalid_argument exception.
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) {
        // catch only the specific exception that is expected from divide().
        // the what() method displays the reason the excpetion occured
        std::cout << "Division error: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // the applications main logic is wrapped in a try block
    // this allows for a final level of exception handling for erros that are not 
    // handled inside the functions
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const ApplicationException& ex) {
        // catch the custom exception first
        std::cout << "Custom exception caught in main(): " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        //catch other exceptions derived from std::exception
        std::cout << "Standard exception in main(): " << ex.what() << std::endl;
    }
    catch (...) {
        // catch any excpetion that was not handled by the previous catch blocks
        std::cout << "Unhandled exception in main(): " << std::endl;
    }
    return 0;
}