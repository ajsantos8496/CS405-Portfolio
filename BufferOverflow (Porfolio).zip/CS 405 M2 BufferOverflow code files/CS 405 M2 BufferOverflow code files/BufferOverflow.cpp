// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cctype> // Added to use std::isspace
#include <iomanip>
#include <iostream>
#include <string>
#include <limits> // Added to use std::numeric_limits

// This function was created to handle the user input and checks if it is too long.
// It returns true if the user enters more characters than the buffer can 
// safely holds. This lets main() know that an overflow was attempted. 

bool getInput(char user_input[], std::size_t buffer_size) {

	// Set the input limit to the size of the character array.
	// The width includes the null terminator, so a buffer of 20 can hold up 
	// to 19 characters. 
	std::cin.width(static_cast<std::streamsize>(buffer_size));

	std::cin >> user_input;

	// If the input operation fails, return true so main() knows
	// that something went wrong with the input
	if (!std::cin) {
		return true;
	}

	// Check the next character waiting in the input stream.
	// If it is not whitespace, there are still extra characters that did not
	// fiT in the buffer
	if (!std::isspace(std::cin.peek())) {

		// Remove the extra characters from the input stream.
		// This keeps them from interfering with the rest of the program 
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		// Tell main() that the user entered too much data
		return true;
	}

	// The input fits in the buffer so no overflow was deteected.
	return false;
}

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";

  // Array has 20 characters of storage.
  // Users can enter up to 19 characters safely
  char user_input[20];
  std::cout << "Enter a value: ";
  
  // Pass the input array and its size into the function.
  // The function returns true if input is too long
  bool buffer_overflow = getInput(user_input, sizeof(user_input));

  // If too much data was entered, let the user know
  if (buffer_overflow) {
	  std::cout << "Buffer overflow detected - input was too long " << std::endl;
	  std::cout << "Extra data was removed \n" << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}
