// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//   FAIL();
//}


// a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is collection empty?
    // collection should start empty
    ASSERT_TRUE(collection->empty());

    // if empty, size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 1 value to collection
    add_entries(1);

    // is the collection still empty?
    // collection should not be empty
    EXPECT_FALSE(collection->empty());

    // if not empty, what must the size be?
    // collection should only have 1 value
    EXPECT_EQ(collection->size(), 1);
}

//  a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // add 5 values to the collection
    add_entries(5);

    // verify the 5 values were added
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5);
}


// a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsValid) {
    // test the collection sizes
    const int testSizes[] = { 0, 1, 5, 10 };

    for (int size : testSizes) {
        // clear the collection before testing next size
        collection->clear();

        // add entries when the requested size is greater than 0
        if (size > 0) {
            add_entries(size);
        }

        // the maximum size should always be at least as large as the number of elements currently
        // in the collection
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsValid) {
    // test the collection sizes
    const int testSizes[] = { 0, 1, 5, 10 };

    for (int size : testSizes) {
        // clear the collection before testing next size
        collection->clear();

        // add entries when the requested size is greater than 0
        if (size > 0) {
            add_entries(size);
        }

        // the capacity should always be at least as large as the number of elements
        // in the collection
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesSize) {
    // add 6 values to collection
    add_entries(6);

    // make sure the collection starts with 6 values
    ASSERT_EQ(collection->size(), 6);

    // increase the collection size to 12 
    collection->resize(12);

    //verify that the collection now contains 12 values
    EXPECT_EQ(collection->size(), 12);
}

// a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesSize) {
    // add 10 values to collection
    add_entries(10);

    // make sure the collection starts with 10 values
    ASSERT_EQ(collection->size(), 10);

    // decrease the collection to 5 values 
    collection->resize(5);

    // verify that the collection now contains 5 values
    EXPECT_EQ(collection->size(), 5);
}

// a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero) {
    // add 8 values to collection
    add_entries(8);

    // make sure the collection starts with 8 elements
    ASSERT_EQ(collection->size(), 8);

    // resize the collection so that it has 0 values
    collection->resize(0);

    // verify that collection is empty
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// a test to verify clear erases the collection
TEST_F(CollectionTest, ClearEmptiesCollection) {
    // add 8 values to collection
    add_entries(8);

    // make sure the collection contains 8 values before clearing it
    ASSERT_EQ(collection->size(), 8);

    // remove all values from collection
    collection->clear();

    // verify that collection is empty
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseAllElements) {
    // add 15 values to collection
    add_entries(15);

    // make sure the collection contains 15 values  before erasing
    ASSERT_EQ(collection->size(), 15);

    // erase all values from beginning to end of collection
    collection->erase(collection->begin(), collection->end());

    // verify that collection is empty
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacity) {
    // add 5 values to collection
    add_entries(5);

    // save the current size and capacity before using reserve()
    const std::size_t originalSize = collection->size();
    const std::size_t originalCapacity = collection->capacity();

    // reserve space for 10 more values than current capacity
    collection->reserve(originalCapacity + 10);

    // reserving space should not change the number of elements
    EXPECT_EQ(collection->size(), originalSize);

    // verify that the capacity increased to at least requested amount
    EXPECT_GE(collection->capacity(), originalCapacity + 10);
}

// a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, AtThrowsForInvalidIndex) {
    // add 5 values to collection
    add_entries(5);

    // index equal to the collection size is outside valid range
    const std::size_t invalidIndex = collection->size();

    // verify that at() throws an out_of_range exception for invalid index
    EXPECT_THROW((void)collection->at(invalidIndex), std::out_of_range);
}

// POSITIVE TEST
// verify that the value added to the collection can be retrieved using at()
TEST_F(CollectionTest, CanRetrieveValue) {
    // add value to collection
    collection->push_back(56);

    //verify the collection contains 1 value
    // and that the value can be retrieved
    ASSERT_EQ(collection->size(), 1);
    EXPECT_EQ(collection->at(0), 56);
}

// NEGATIVE TEST
// verify that accessing an empty collection with at() produces out_of_range exception
TEST_F(CollectionTest, AtThrowsOnEmptyCollection) {
    // make sure collection is empty first
    ASSERT_TRUE(collection->empty());

    // index 0 is invalid because collection has no values
    EXPECT_THROW((void)collection->at(0), std::out_of_range);
}